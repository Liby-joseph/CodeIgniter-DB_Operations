<?php
session_start();
$id=$_SESSION['user'];
include("connect.php");

session_unset();
header("location:index.html");
?>