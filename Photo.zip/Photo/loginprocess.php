<?php 

include ("connect.php");
if(extract($_POST))
{
    
    $sql1="SELECT * FROM user WHERE username='$username' && password='$password'";
	$exe=mysqli_query($con,$sql1);
	if($row=mysqli_fetch_array($exe))
	{
		$id=$row['id'];
		$name=$row['name'];
		session_start();
			$_SESSION['x']=$id;
			header("location:admin/page");
		
	}
	else
	{
		
		echo '<script language="javascript">';
		echo 'alert("INCORRECT USERNAME OR PASSWORD".$id)';
		echo '</script>';
		header("location:index.html");
		header("location:index.html");
		
	}
	
}


?>